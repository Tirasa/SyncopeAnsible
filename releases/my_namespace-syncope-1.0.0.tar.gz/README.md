Test module logic
=========

1. First make sure to edit the file `plugins/modules/syncope_change_user_status/args.json` 
according to your needs.

1. Test the module logic by running:
```sh
python -m changeUserStatus args.json
```

1. Install [Mazer CLI](https://galaxy.ansible.com/docs/mazer/install.html#latest-stable-release)
```sh
pip3 install mazer
```

1. Edit `galaxy.yml` properly and use `mazer` to build and publish the collection
```sh
mazer build 

mazer publish --api-key=SECRET path/to/namespace_name-collection_name-1.0.12.tar.gz
```